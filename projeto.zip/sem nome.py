a = "abacate"

if ("z" in a):
    print("achou")
else:
    print("não")