x = round(5.76543 - 5.76545, 1)
print(x)

if x == 0:
    print("Zero")
else:
    print("ERRO")
