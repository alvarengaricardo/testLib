def variaveis():
    list_total = []
    list_pass = []
    list_error = []



